# Entrega final

Pendiente de incorporar:
- Informe completo del ejercicio original y adaptado, con los dos ajustes menores de la Auditoría 2 aplicados a la copia final.
- Evidencia de verificación manual y firmas físicas de ambas estudiantes.
- Enlace al video de presentación, de máximo 15 minutos.

La versión 2 del ejercicio original es la base de esa sección del informe. Esta carpeta no contiene todavía una entrega final ni una certificación de verificación.

