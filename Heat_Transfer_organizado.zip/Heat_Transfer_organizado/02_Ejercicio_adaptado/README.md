# Ejercicio adaptado

Pendiente de desarrollar. Debe demostrar un calentamiento o enfriamiento más rápido mediante una comparación de tiempos con condiciones y propiedades justificadas. Una menor temperatura estacionaria por sí sola no demuestra menor tiempo.

Al disponer de resultados se organizarán versiones con sus prompts, reportes, código, gráficas y auditorías.

