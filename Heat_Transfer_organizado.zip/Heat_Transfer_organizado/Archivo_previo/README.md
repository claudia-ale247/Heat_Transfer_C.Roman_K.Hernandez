# Archivo previo

Se conservan sin alterar los archivos existentes antes de organizar el reinicio con dos prompts. `Prompt_Engineering_Iterations.md` contiene los intentos previos y no corresponde a las versiones nuevas de `01_Ejercicio_original`.

Los otros dos archivos conservados eran archivos vacíos, no carpetas ni una plantilla de clase completada.

