----------------------------Promt 1----------------------------

Actúa como un ingeniero principiante que prepara una solución de transferencia de calor para revisión técnica. Ayúdame a resolver el ejercicio 5-34 y documentar el proceso según la rúbrica adjunta. Explica en español, paso a paso, con ecuaciones, sustituciones y unidades.

Referencias que debes utilizar
- 092126 2.pdf: instrucciones, rúbrica y enunciado del ejercicio 5-34. Su figura continúa en la página siguiente.
- Libreta.pdf: presentaciones recientes. Consulta especialmente la sección 5-3, conducción unidimensional estacionaria, y el método de balances de energía para formular diferencias finitas en nodos interiores, fronteras e interfaces.
- Libreta Examen 2.pdf: conducción en paredes compuestas, resistencias térmicas y resistencia de contacto.
Identifica las páginas o diapositivas que utilizas. Si algún contenido no es legible o no está disponible, indícalo; no inventes referencias ni instrucciones del profesor.

Contexto del proyecto

Trabajamos en pareja. El proyecto requiere resolver un ejercicio original y una versión adaptada para lograr calentamiento o enfriamiento más rápido, documentar los prompts y respuestas en GitHub, auditar manualmente los cálculos, entregar un reporte firmado a mano por ambos estudiantes y presentar un video de máximo 15 minutos.

En esta primera etapa, resuelve únicamente el ejercicio original. No cambies sus datos. La adaptación se desarrollará después.

Datos del ejercicio 5-34

Una placa no metálica está unida sobre una placa de cobre–silicio ASME SB-96:
- Metal: \(k_m=36\ \mathrm{W/(m\cdot K)}\), \(L_m=0.030\ \mathrm m\).
- No metal: \(k_n=0.05\ \mathrm{W/(m\cdot K)}\), \(L_n=0.020\ \mathrm m\).
- Superficie inferior del metal: flujo de calor entrante uniforme de \(q''_{\mathrm{in}}=150\ \mathrm{W/m^2}\).
- Superficie superior del no metal: convección con aire a \(T_\infty=15^\circ\mathrm C\), con \(h=5\ \mathrm{W/(m^2\cdot K)}\).
- Espaciamiento nodal uniforme: \(\Delta x=0.005\ \mathrm m\).
- Límite de temperatura del metal indicado en el enunciado: \(93^\circ\mathrm C\).
Verifica estos datos contra el archivo antes de resolver.

Lo que debes calcular
1. La temperatura en cada nodo mediante diferencias finitas.
2. La distribución de temperatura como función de \(x\), con tabla y gráfica.
3. Si la temperatura máxima del metal cumple el límite proporcionado por el ejercicio.
4. El valor umbral de \(h\) para que la temperatura máxima del metal sea \(93^\circ\mathrm C\), aclarando qué condición sobre \(h\) se necesita para mantenerla estrictamente por debajo.
Procedimiento requerido
1. Explica el sistema físico, la dirección del calor y las incógnitas. Distingue flujo de calor \(\mathrm{W/m^2}\) de tasa de transferencia de calor \(\mathrm W\).
2. Establece y justifica las suposiciones: estado estacionario, conducción unidimensional, conductividades constantes en cada capa, ausencia de generación interna, contacto térmico perfecto y radiación despreciable. Distingue las condiciones explícitas del enunciado de las suposiciones del modelo. Explica por qué se resuelve como estacionario y por qué usar diferencias finitas no implica que sea transitorio.
3. Define \(x=0\) en la superficie inferior y \(x=0.050\ \mathrm m\) en la superior. Numera los nodos del 0 al 10:
   - Nodo 0: flujo impuesto.
   - Nodos 1–5: interior del metal.
   - Nodo 6: interfaz, \(x=0.030\ \mathrm m\).
   - Nodos 7–9: interior del no metal.
   - Nodo 10: convección.
4. Parte del balance general de energía y muestra qué términos se cancelan. Deriva detalladamente las ecuaciones para:
   - Un nodo interior del metal.
   - Un nodo interior del no metal.
   - La frontera inferior.
   - La interfaz.
   - La frontera superior.
   Usa volúmenes de control alrededor de los nodos, coherentes con las presentaciones. Explica los signos, las distancias y la cancelación del área. En la interfaz, conserva las conductividades diferentes; no uses automáticamente el promedio aritmético de las temperaturas vecinas.
5. Presenta las 11 ecuaciones con sus coeficientes numéricos y resuelve el sistema. Si utilizas código, incluye código reproducible y explica cómo funciona. No sustituyas la solución por diferencias finitas por una solución exclusiva mediante resistencias térmicas.
6. Presenta una tabla con nodo, posición, material o frontera y temperatura. Grafica \(T(x)\), señalando la interfaz y el límite de \(93^\circ\mathrm C\). Explica las pendientes en ambos materiales.
7. Identifica la temperatura máxima del metal y responde la pregunta de cumplimiento según el límite del enunciado, sin presentar esto como una certificación normativa real del equipo.
8. Calcula el \(h\) umbral manteniendo constantes todos los demás datos. Muestra el despeje, las unidades y comprueba el resultado sustituyéndolo.
Verificación y auditoría

Realiza una comprobación independiente mediante resistencias térmicas. Verifica también:
- El balance global de energía.
- La continuidad del flujo en la interfaz.
- La satisfacción de las condiciones de frontera.
- Los residuos de las 11 ecuaciones.
- La coherencia física de las temperaturas y sus unidades.
Incluye una tabla con: resultado o ecuación, método de comprobación y resultado de la verificación. Conserva suficiente precisión durante los cálculos y redondea al presentar.

Esta verificación hecha por AI no sustituye la auditoría manual de los estudiantes. Identifica los cálculos que debemos reproducir a mano. No inventes errores de AI ni afirmes que nosotros ya verificamos o firmamos el trabajo. Si detectas un error en tu solución, muestra la corrección de forma transparente.

Conexión con la adaptación posterior

Al finalizar, explica brevemente qué faltaría para demostrar un enfriamiento más rápido mediante un análisis transitorio. No confundas una temperatura estacionaria menor con un menor tiempo de enfriamiento. No inventes densidades, calores específicos ni una identidad para el material no metálico: señala los datos adicionales que habría que obtener y las condiciones que habría que definir.

Organiza la respuesta para que podamos guardar este prompt, tu solución y nuestras futuras correcciones en GitHub. Prioriza una solución comprensible y verificable, sin saltarte pasos algebraicos importantes.



----------------------------RESPUESTA 1 POR CLAUDE AI------------------------

# Ejercicio 5-34: solución original (diferencias finitas, estacionario)

Resuelvo el 5-34 con los datos de tu prompt, que coinciden con el enunciado del PDF. Antes de empezar, una corrección: en mi mensaje anterior supuse que tu ejercicio base era el 5-36 por el resaltado amarillo. Con este prompt trabajo el 5-34.

**Sobre las libretas:** no extraje páginas de `Libreta.pdf` ni de `Libreta_Examen_2.pdf`, así que no cito diapositivas. Todo está derivado de los principios de balance de energía. Cuando revises, agrega tú las referencias de página.

## 1. Sistema físico

El calor entra por abajo (x = 0) con flujo q″ = 150 W/m² y sale por convección arriba (x = 50 mm). Con la geometría unidimensional, la tasa de transferencia (W) es q″·A, y A se cancela en todas las ecuaciones. Las incógnitas son T₀…T₁₀.

## 2. Suposiciones

- **Del enunciado:** flujo uniforme de 150 W/m² abajo, convección con T∞ = 15 °C y h = 5 W/m²·K arriba, Δx = 5 mm.
- **Del modelo:** estado estacionario, conducción 1D, k constante en cada capa, sin generación, contacto perfecto (sin resistencia de contacto) y radiación despreciable.
- **¿Por qué es estacionario?** El enunciado pide la temperatura del equipo en operación. Las diferencias finitas aquí solo discretizan el espacio, y por eso no hay término ρc·∂T/∂t.

## 3. Ecuaciones por balance de energía

La base es E_ent − E_sal + E_gen = ΔE/Δt. En estacionario y sin generación queda Σ q_entrando = 0 en cada volumen de control. Los volúmenes tienen ancho Δx en los nodos interiores y Δx/2 en las fronteras. El área A se cancela.

| Nodo | Balance | Ecuación |
|---|---|---|
| 0 (flujo impuesto) | q″ + k_m(T₁−T₀)/Δx = 0 | T₀ − T₁ = q″Δx/k_m |
| 1–5 y 7–9 (interiores) | k(T_{i−1}−T_i)/Δx + k(T_{i+1}−T_i)/Δx = 0 | T_{i−1} − 2T_i + T_{i+1} = 0 |
| 6 (interfaz) | k_m(T₅−T₆)/Δx + k_n(T₇−T₆)/Δx = 0 | k_m T₅ − (k_m+k_n)T₆ + k_n T₇ = 0 |
| 10 (convección) | k_n(T₉−T₁₀)/Δx + h(T∞−T₁₀) = 0 | (k_n/Δx) T₉ − (k_n/Δx + h) T₁₀ = −hT∞ |

**Signos y distancias:** cada término de conducción es k(T_vecino − T_nodo)/Δx, positivo cuando el calor entra al nodo. En la interfaz, el volumen de control tiene medio metal y medio no metal. Como no hay generación ni almacenamiento, esas mitades no aportan términos y solo quedan los dos flujos conductivos. Cada flujo conserva su propia k, así que la interfaz **no** es un promedio de T₅ y T₇.

**Coeficientes numéricos.** Aquí k_m/Δx = 7200 W/m²·K y k_n/Δx = 10 W/m²·K.

- Nodo 0: T₀ − T₁ = 0.0208333
- Nodos 1–5: T_{i−1} − 2T_i + T_{i+1} = 0
- Nodo 6: 7200 T₅ − 7210 T₆ + 10 T₇ = 0
- Nodos 7–9: T_{i−1} − 2T_i + T_{i+1} = 0
- Nodo 10: 10 T₉ − 15 T₁₀ = −75

## 4. Solución

| Nodo | x (mm) | Zona | T (°C) |
|---|---|---|---|
| 0 | 0 | Frontera, flujo impuesto | 105.1250 |
| 1 | 5 | Metal | 105.1042 |
| 2 | 10 | Metal | 105.0833 |
| 3 | 15 | Metal | 105.0625 |
| 4 | 20 | Metal | 105.0417 |
| 5 | 25 | Metal | 105.0208 |
| 6 | 30 | Interfaz | 105.0000 |
| 7 | 35 | No metal | 90.0000 |
| 8 | 40 | No metal | 75.0000 |
| 9 | 45 | No metal | 60.0000 |
| 10 | 50 | Frontera, convección | 45.0000 |

La gráfica T(x) con la interfaz y el límite de 93 °C está en `T_vs_x_5_34.png`, y el código reproducible está en `ej_5_34.py`.

**Pendientes.** En el metal, dT/dx = q″/k_m ≈ 4.17 K/m, es decir 0.021 K por nodo, casi plana. En el no metal, dT/dx = q″/k_n = 3000 K/m, es decir 15 K por nodo. Todo el salto térmico ocurre en el aislante.

## 5. Cumplimiento

La temperatura máxima del metal es 105.125 °C en x = 0, y **supera el límite de 93 °C del enunciado**. Bajo esas condiciones, la placa SB-96 **no cumpliría** el criterio planteado en el ejercicio. Esto es solo respecto al límite que da el problema, no una certificación normativa real.

## 6. h umbral

La temperatura máxima es T₀ = T∞ + q″(1/h + L_n/k_n + L_m/k_m). Con T₀ = 93 °C:

1/h = (93 − 15)/150 − 0.4 − 0.000833 = 0.119167 m²·K/W

**h = 8.39 W/m²·K**

Comprobación: con h = 8.3916, T₀ = 93.000 °C. Para mantenerla **estrictamente por debajo** de 93 °C se necesita h > 8.39 W/m²·K. Con h = 8.5, T₀ = 92.77 °C.

## 7. Verificación (hecha por la AI)

| Resultado | Método | Resultado |
|---|---|---|
| Las 11 temperaturas | Resistencias: R_conv = 0.2, R_n = 0.4, R_m = 0.000833 m²·K/W | T₁₀ = 45, T₆ = 105, T₀ = 105.125: coincide |
| Balance global | q″_in = h(T₁₀ − T∞) | 150 = 5·30 = 150 W/m²: cumple |
| Continuidad en la interfaz | Flujo en cada lado | Metal: 7200·0.0208 = 150; no metal: 10·15 = 150: cumple |
| Condiciones de frontera | Nodos 0 y 10 | Ambas se satisfacen |
| Residuos de las 11 ecuaciones | Código | Máximo ≈ 1×10⁻¹⁰: cumple |
| Coherencia física | Signos y unidades | T decrece hacia el aire y las unidades son consistentes: cumple |

**Qué deben reproducir a mano:** (a) los coeficientes 7200, 7210, 10 y 15; (b) la cadena de resistencias y T₀ = 105.125 °C; (c) el despeje de h = 8.39; (d) el residuo del nodo 6 con T₅ = 105.0208 y T₇ = 90. Esta verificación de la AI no sustituye su auditoría manual, y no he afirmado ningún error de la AI porque no encontré ninguno.

## 8. Conexión con la adaptación (enfriamiento)

Una temperatura estacionaria menor no implica un enfriamiento más rápido. Para demostrar tiempos necesitan un análisis transitorio, con estos datos y condiciones por definir:

- Densidad y calor específico de cada capa (los del no metal no están en el enunciado, no los inventes).
- Condición inicial (por ejemplo, T = 105 °C en todo el espesor) y qué pasa con el flujo de 150 W/m² (se apaga o no).
- Biot (para ver si aplica capacitancia concentrada) y Fourier (para el paso de tiempo y la estabilidad del método explícito).




----------------------------Promt 2----------------------------

Revisa y mejora tu primera solución del ejercicio 5-34 a partir de las siguientes observaciones. Presenta una versión completa y corregida, manteniendo el método de diferencias finitas y los datos originales.

1. Signos de las pendientes
Definiste x desde la base metálica hacia la superficie expuesta al aire. Como la temperatura disminuye en esa dirección, corrige las pendientes utilizando la ley de Fourier:
q″ = −k(dT/dx).
Explica el signo y calcula la pendiente en cada material con sus unidades.

2. Caídas de temperatura
Corrige la afirmación “todo el salto térmico ocurre en el aislante”. Calcula por separado las caídas de temperatura en el metal, en el no metal y entre la superficie exterior y el aire. Explica en cuál ocurre la mayor caída y por qué.

3. Redondeo y comprobación del flujo
Revisa la igualdad 7200 × 0.0208 = 150, porque ese producto es 149.76 W/m². Utiliza valores sin redondear para verificar los balances y redondea únicamente los resultados que presentes. Distingue un error de redondeo de un error en el planteamiento.

4. Coeficiente de convección límite
Presenta el valor de h con suficiente precisión y distingue entre:
- El valor umbral que produce una temperatura máxima exactamente igual a 93 °C.
- La condición necesaria para mantenerla estrictamente por debajo de 93 °C.
Comprueba también la temperatura máxima para h = 8.5 W/(m²·K).

5. Datos y suposiciones
Separa los datos proporcionados de las suposiciones del modelo. Explica brevemente el estado estacionario, la conducción unidimensional, las conductividades constantes por material, la ausencia de generación interna, el contacto térmico perfecto y la omisión de radiación.
No presentes una suposición como si estuviera indicada explícitamente en el enunciado. El uso de diferencias finitas, por sí solo, no determina si un problema es estacionario o transitorio.

6. Desarrollo de las ecuaciones
Parte del balance de energía y muestra cómo se simplifica con las suposiciones adoptadas. Desarrolla las ecuaciones de la frontera con flujo impuesto, los nodos interiores, la interfaz y la frontera con convección.
Explica la diferencia entre el espesor del volumen de control de frontera, Δx/2, y la distancia entre nodos vecinos, Δx.
Presenta las 11 ecuaciones numéricas, identificando cada nodo. En la interfaz, aclara que la temperatura no es el promedio aritmético de las temperaturas vecinas; para esta malla uniforme, corresponde a un promedio ponderado por las conductividades.
Incluye un procedimiento de solución que podamos seguir y reproducir a mano, además del cálculo con Python.

7. Unidades y verificación
Distingue la resistencia térmica R, en K/W, de la resistencia por unidad de área R″, en m²·K/W.
Comprueba la solución mediante resistencias térmicas, balance global, continuidad del flujo en la interfaz y condiciones de frontera.
Para evaluar los residuos, expresa todas las ecuaciones como balances de flujo por unidad de área, en W/m². No presentes un único residuo máximo calculado a partir de ecuaciones con unidades diferentes. Define cómo calculas los residuos e indica sus unidades.

8. Entrega completa
Incluye:
- Tabla de datos y suposiciones.
- Desarrollo y solución de las 11 ecuaciones.
- Tabla de temperaturas de los nodos 0 a 10.
- Gráfica de T frente a x, señalando la interfaz y el límite de 93 °C.
- Evaluación del cumplimiento del límite de temperatura.
- Cálculo y comprobación de h.
- Verificaciones y explicación de las correcciones realizadas.
- Código completo y reproducible de Python.





----------------------------RESPUESTA 2 POR CLAUDE AI------------------------
# Ejercicio 5-34: solución corregida (v2)

## 1. Datos

**Del enunciado:**

| Dato | Valor |
|---|---|
| Placa no metálica | k_n = 0.05 W/m·K, L_n = 20 mm |
| Placa ASME SB-96 | k_m = 36 W/m·K, L_m = 30 mm |
| Flujo de calor en la superficie 1 (inferior del metal) | q″_in = 150 W/m² (entrante, uniforme) |
| Convección en la superficie 2 (superior del no metal) | T∞ = 15 °C, h = 5 W/m²·K |
| Espaciamiento nodal | Δx = 5 mm (uniforme) |
| Límite térmico de la placa SB-96 | 93 °C |

## 2. Suposiciones del modelo

El enunciado no dice "estado estacionario" de forma explícita. Esa es una interpretación del modelo, y las demás suposiciones también lo son:

- **Estado estacionario.** El enunciado pide la temperatura en cada nodo con un flujo y una convección constantes, y compara con un límite de operación. No da propiedades térmicas de almacenamiento (ρ, c_p) ni condiciones iniciales ni tiempos, así que un problema transitorio no podría plantearse con los datos dados. Con esta interpretación se descarta el término de almacenamiento ρc ∂T/∂t. Las diferencias finitas solo discretizan el espacio.
- **Conducción unidimensional.** Se supone que las placas son anchas respecto a su espesor y que los bordes laterales están aislados o lejos del área de interés, de modo que los efectos laterales son despreciables. Entonces T = T(x). Esto significa que la temperatura es uniforme en cada plano perpendicular a x, pero **no** que sea uniforme a través del espesor. De hecho, T varía con x.
- **k constante en cada material.** Es razonable para el rango de temperaturas involucrado, y permite sacar k de la derivada.
- **Sin generación volumétrica.** El calor se aplica en una frontera, no dentro del material. Por eso el término ė_gen·V desaparece de todos los balances.
- **Contacto térmico perfecto.** El enunciado no da resistencia de contacto. Con la suposición, T es continua en la unión y el flujo se conserva.
- **Radiación despreciable.** El enunciado solo da h para convección. Cualquier radiación quedaría incluida en h o se omite.

## 3. Nodos

x = 0 en la superficie inferior del metal y x = 50 mm en la superficie superior del no metal. Hay 11 nodos (0 a 10): el nodo 0 tiene flujo impuesto, los nodos 1 a 5 son interiores del metal, el nodo 6 es la interfaz (x = 30 mm), los nodos 7 a 9 son interiores del no metal y el nodo 10 tiene convección.

## 4. Formulación

**Balance general.** Para un volumen de control: Ė_ent − Ė_sal + Ė_gen = dE/dt. Aquí Ė son tasas de energía en W, y se descompone en q (tasa de transferencia, W) = q″ (flujo, W/m²) · A. Con estado estacionario y sin generación queda Σ Q̇_entra = 0. Dividir entre A permite trabajar con flujos q″ en W/m², porque A se cancela.

**Conducción entre nodos.** Para el flujo que llega del nodo vecino, q″ = k (T_vecino − T_nodo)/Δx. El signo es positivo cuando el calor entra al nodo.

**Por qué los volúmenes de frontera miden Δx/2 de ancho.** El nodo 0 está sobre la superficie, así que su volumen de control solo se extiende hacia adentro del material, mitad de la distancia al siguiente nodo. Sin embargo, el calor conductivo sigue fluyendo entre los *nodos* 0 y 1, que están separados Δx. Por eso el ancho del volumen es Δx/2, pero el gradiente se calcula sobre Δx. Como no hay almacenamiento ni generación, el ancho del volumen no aparece en el balance estacionario.

**Derivaciones:**

- **Nodo 0 (flujo impuesto):** q″_in + k_m(T₁ − T₀)/Δx = 0, es decir T₀ − T₁ = q″_in Δx / k_m.
- **Nodo interior** (cualquier material): k(T_{i−1} − T_i)/Δx + k(T_{i+1} − T_i)/Δx = 0, es decir T_{i−1} − 2T_i + T_{i+1} = 0.
- **Nodo 6 (interfaz):** el volumen de control es medio metal y medio no metal. Entra calor del metal por la izquierda y del no metal por la derecha: k_m(T₅ − T₆)/Δx + k_n(T₇ − T₆)/Δx = 0. Despejando T₆ = (k_m T₅ + k_n T₇)/(k_m + k_n). Es un **promedio ponderado por las conductividades** (con espaciamiento uniforme). No es el promedio aritmético simple. Aquí el peso del metal es 36/36.05 = 99.86 %, y el del no metal es 0.14 %.
- **Nodo 10 (convección):** k_n(T₉ − T₁₀)/Δx + h(T∞ − T₁₀) = 0.

## 5. Las 11 ecuaciones con coeficientes numéricos

Con k_m/Δx = 7200 W/m²·K, k_n/Δx = 10 W/m²·K y h = 5 W/m²·K:

| # | Nodo | Ecuación |
|---|---|---|
| 1 | 0 | −7200 T₀ + 7200 T₁ = −150 |
| 2 | 1 | T₀ − 2T₁ + T₂ = 0 |
| 3 | 2 | T₁ − 2T₂ + T₃ = 0 |
| 4 | 3 | T₂ − 2T₃ + T₄ = 0 |
| 5 | 4 | T₃ − 2T₄ + T₅ = 0 |
| 6 | 5 | T₄ − 2T₅ + T₆ = 0 |
| 7 | 6 | 7200 T₅ − 7210 T₆ + 10 T₇ = 0 |
| 8 | 7 | T₆ − 2T₇ + T₈ = 0 |
| 9 | 8 | T₇ − 2T₈ + T₉ = 0 |
| 10 | 9 | T₈ − 2T₉ + T₁₀ = 0 |
| 11 | 10 | 10 T₉ − 15 T₁₀ = −75 |

(Las ecuaciones 2 a 6 y 8 a 10 están normalizadas en temperatura, y la 1, 7 y 11 son balances de flujo en W/m². Por eso más adelante reporto los residuos por tipo.)

**Resolución a mano, paso a paso:**

1. Ec. 1: T₀ − T₁ = 150/7200 = 1/48 = 0.0208333… K.
2. Ecs. 2 a 6: T_{i−1} − T_i = T_i − T_{i+1}, así que la caída entre nodos consecutivos del metal es siempre 1/48 K. Por tanto T₁ = T₀ − 1/48, …, T₅ = T₀ − 5/48 y T₆ = T₅ − (T₅ − T₆) donde la diferencia se obtiene en el paso siguiente.
3. Ec. 7: 7200(T₅ − T₆) = 10(T₆ − T₇). Como T₅ − T₆ = 1/48 (misma caída que en el resto del metal, por continuidad del flujo), T₆ − T₇ = 7200/(48·10) = **15 K**. Entonces T₆ = T₀ − 6/48 = T₀ − 0.125.
4. Ecs. 8 a 10: la caída entre nodos del no metal es constante, 15 K, así que T₇ = T₆ − 15, T₈ = T₆ − 30, T₉ = T₆ − 45 y T₁₀ = T₆ − 60.
5. Ec. 11 con T₉ = T₁₀ + 15: 10(T₁₀ + 15) − 15T₁₀ = −75 → 150 − 5T₁₀ = −75 → **T₁₀ = 45 °C**.
6. Hacia atrás: T₆ = 45 + 60 = **105 °C**, y T₀ = 105 + 0.125 = **105.125 °C**. Los demás nodos salen de las caídas anteriores.

El script `ej_5_34_v2.py` repite este procedimiento en fracciones exactas (T₀ = 841/8, T₁ = 5045/48, …) y lo compara con `numpy.linalg.solve` (diferencia máxima ≈ 6×10⁻¹¹ °C).

## 6. Solución, tabla y gráfica

| Nodo | x (mm) | Zona | T (°C) |
|---|---|---|---|
| 0 | 0 | Frontera, flujo impuesto | 105.1250 |
| 1 | 5 | Metal | 105.1042 |
| 2 | 10 | Metal | 105.0833 |
| 3 | 15 | Metal | 105.0625 |
| 4 | 20 | Metal | 105.0417 |
| 5 | 25 | Metal | 105.0208 |
| 6 | 30 | Interfaz | 105.0000 |
| 7 | 35 | No metal | 90.0000 |
| 8 | 40 | No metal | 75.0000 |
| 9 | 45 | No metal | 60.0000 |
| 10 | 50 | Frontera, convección | 45.0000 |

La gráfica `T_vs_x_5_34_v2.png` sombrea las dos capas, marca la interfaz y el límite de 93 °C, y en el panel derecho amplía el metal.

**Pendientes.** Con q″ = −k dT/dx y q″ = +150 W/m² (en la dirección +x):

- Metal: dT/dx = −150/36 = **−4.1667 K/m**.
- No metal: dT/dx = −150/0.05 = **−3000 K/m**.

La temperatura baja al aumentar x, y por eso las pendientes son negativas. En magnitud, la del no metal es 720 veces mayor, que es la razón k_m/k_n. La pendiente del metal es pequeña, pero **no es cero**: a lo largo de los 30 mm suma una caída real de 0.125 °C, y sin ella no habría flujo de calor.

**Caídas de temperatura por capa** (ΔT = q″ R″):

| Tramo | R″ (m²·K/W) | ΔT (°C) | % de 90.125 °C |
|---|---|---|---|
| Metal (0→6) | 0.000833 | 0.125 | 0.14 % |
| No metal (6→10) | 0.4 | 60 | 66.6 % |
| Película convectiva (10→aire) | 0.2 | 30 | 33.3 % |
| Total (T₀ − T∞) | 0.600833 | 90.125 | 100 % |

Entre los sólidos, la caída se concentra en el no metal porque su R″ = L/k es unas 480 veces la del metal (0.4 contra 0.000833), con el mismo flujo. Además, la película convectiva aporta otros 30 °C. Es una **caída a través del material**, no un salto en la interfaz: con contacto perfecto, T₆ = 105 °C es la misma desde ambos lados.

## 7. Evaluación del límite térmico

La temperatura máxima del metal es **T₀ = 105.125 °C**, en la superficie inferior. Supera el límite de 93 °C del enunciado en 12.125 °C. Bajo esos datos, la placa SB-96 **no cumple** el criterio planteado. Esto es respecto al límite que da el ejercicio, no una certificación normativa del equipo.

## 8. Cálculo de h

T₀ = T∞ + q″(1/h + L_n/k_n + L_m/k_m). Con T₀ = 93 °C, todo lo demás constante:

- (93 − 15)/150 = 0.52 m²·K/W
- 1/h = 0.52 − 0.4 − 0.000833… = 143/1200 = 0.1191666… m²·K/W

**Umbral exacto (T₀ = 93 °C): h\* = 1200/143 = 8.391608… W/m²·K.**

**Condición estricta (T₀ < 93 °C):** como T₀ disminuye al aumentar h, se necesita **h > 1200/143 ≈ 8.391608 W/m²·K**. Redondear a 8.39 hacia abajo no sirve como condición exacta: con h = 8.3916, T₀ = 93.000018 °C, que todavía excede el límite.

**Valor práctico:** h = 8.5 W/m²·K (por encima del umbral) da T₀ = 92.772 °C. Como referencia, h = 9 W/m²·K da 91.792 °C.

## 9. Verificaciones (hechas por la AI, con precisión interna completa)

**Resistencias por unidad de área, R″ (m²·K/W)**, y su relación con las resistencias totales R (K/W) para un área A: R″_m = L_m/k_m = 8.333×10⁻⁴, R″_n = L_n/k_n = 0.4 y R″_conv = 1/h = 0.2. Las resistencias en K/W serían L/(kA) y 1/(hA), es decir R″/A. Aquí se trabaja por unidad de área.

| Resultado o ecuación | Método | Resultado |
|---|---|---|
| T₁₀, T₆ y T₀ | Resistencias: 15 + 150·0.2, + 150·0.4, + 150·8.333×10⁻⁴ | 45; 105; 105.125 °C, coincide |
| Los 11 nodos | Aritmética exacta (fracciones) contra solución numérica | Diferencia máxima ≈ 6×10⁻¹¹ °C |
| Flujo entre nodos, 10 tramos | k(T_i − T_{i+1})/Δx | 150.000000 W/m² en todos |
| Balance global | h(T₁₀ − T∞) contra q″_in | 5·30 = 150 contra 150 W/m², coincide |
| Continuidad en la interfaz | Flujo en ambos lados | 150 W/m² por ambos lados |
| Condiciones de frontera | Nodos 0 y 10 | Se satisfacen (residuos abajo) |
| Residuos, por tipo | Balance de flujo en W/m² | Ver nota abajo |

**Residuos (W/m²).** Calculados con balances de flujo, así todos comparten unidades: nodo 0, 0; interfaz, 0; nodo 10, ≈ 3×10⁻¹⁴; nodos interiores, máximo ≈ 1.4×10⁻¹⁴. Son cero hasta el límite de la aritmética de punto flotante. No presento un único residuo bruto porque el sistema anterior mezclaba ecuaciones normalizadas en K con balances en W/m².

**Efecto del redondeo (no es un error de las ecuaciones).** Con T₅ = 105.0208 redondeado, 7200(T₅ − 105) = 7200 × 0.0208 = 149.76 W/m², y no 150. Al sustituir en la ecuación de la interfaz: 7200(105.0208) − 7210(105) + 10(90) = 756 149.76 − 757 050 + 900 = **−0.24 W/m²** (0.16 % de 150). Con el valor completo T₅ = 105.0208333…, la diferencia (T₅ − 105) es exactamente 1/48 y el producto 7200/48 es exactamente 150. El residuo de −0.24 viene solo de truncar a 4 decimales: 7200 × 0.0000333… = 0.24. Las ecuaciones están bien.

**Qué conviene reproducir a mano:** los coeficientes 7200, 7210, 10 y 15; la resolución de la sección 5 (pasos 1 a 6); el cálculo de h\*, con el redondeo mostrado arriba; y la sustitución de h = 8.5.

## 10. Para el análisis transitorio (no desarrollado)

Faltarían: ρ y c_p de cada capa (en especial del no metal, que no están en el enunciado), un criterio de "enfriamiento" (por ejemplo, tiempo para bajar a una temperatura dada), y la condición del flujo (si se apaga o no). Una temperatura inicial uniforme, por ejemplo 105 °C en todo el espesor, sería una **condición nueva**, no el perfil estacionario calculado aquí, que va de 105.125 a 45 °C. También habría que definir Bi (si aplica la capacitancia concentrada) y Fo (para el paso de tiempo y la estabilidad).

## 11. Registro de cambios respecto a la primera respuesta

| Cambio | Antes | Ahora |
|---|---|---|
| Signo de pendientes | +4.17 y +3000 K/m | −4.1667 y −3000 K/m, con q″ = −k dT/dx |
| Caídas de temperatura | "Todo el salto ocurre en el aislante" | Tabla por capa: 0.125, 60 y 30 °C, y se aclara que no hay salto en la interfaz |
| Verificación de flujo | 7200(0.0208) = 150 | Muestra que con redondeo da 149.76, y que con precisión completa da 150 |
| Umbral de h | "h > 8.39" | h\* = 1200/143; condición h > 1200/143; ejemplo práctico h = 8.5 → 92.772 °C |
| Suposiciones | Lista breve | Distingue datos y modelo, y justifica cada una |
| Desarrollo | Familias de ecuaciones | Derivación por nodo, 11 ecuaciones con coeficientes y resolución a mano |
| Resistencias | Sin distinguir | R″ (m²·K/W) distinguida de R (K/W) |
| Residuos | Un solo máximo bruto | Separados por tipo, en W/m² |
| Código y gráfica | Un panel | `ej_5_34_v2.py` con solución exacta, residuos y flujos; gráfica con capas y ampliación del metal |


