# Proyecto de Transferencia de Calor
**Integrantes:** C. Román y K. Hernández.

Resolución del ejercicio 5-34 mediante diferencias finitas y desarrollo posterior de una adaptación para lograr calentamiento o enfriamiento más rápido.

## Ejercicio original
| Registro | Prompt | Respuesta de Claude | Código | Gráfica | Auditoría |
|---|---|---|---|---|---|
| Versión 1 | [Prompt 1](01_Ejercicio_original/Version_1/Prompt_1.md) | [Reporte 1](01_Ejercicio_original/Version_1/reporte_original_v1.md) | [Python v1](01_Ejercicio_original/Version_1/ej_5_34_v1.py) | [Gráfica v1](01_Ejercicio_original/Version_1/T_vs_x_5_34_v1.png) | [Auditoría 1](01_Ejercicio_original/Version_1/Auditoria_1.md) |
| Versión 2 | [Prompt 2](01_Ejercicio_original/Version_2/Prompt_2.md) | [Reporte 2](01_Ejercicio_original/Version_2/reporte_original_v2.md) | [Python v2](01_Ejercicio_original/Version_2/ej_5_34_v2.py) | [Gráfica v2](01_Ejercicio_original/Version_2/T_vs_x_5_34_v2.png) | [Auditoría 2](01_Ejercicio_original/Version_2/Auditoria_2.md) |

La versión 2 es la base del informe del ejercicio original. Los reportes, códigos y gráficas se conservan tal como fueron recibidos de Claude; dos ajustes menores para la entrega se documentan en la Auditoría 2.

## Otras partes del proyecto
- [Ejercicio adaptado](02_Ejercicio_adaptado/): pendiente.
- [Verificación manual](03_Verificacion_manual/): cálculos realizados según lo indicado por las estudiantes; pendiente incorporar la evidencia.
- [Entrega final](04_Entrega_final/): pendiente informe completo firmado y enlace al video.
- [Archivo previo](Archivo_previo/): registro conservado de los intentos anteriores al reinicio con dos prompts.

## Reproducir los cálculos
Descargar el código de la versión elegida e instalar Python con NumPy y Matplotlib:
```bash
pip install numpy matplotlib
python3 ej_5_34_v2.py
```
Ejecutar desde una copia local de la carpeta de esa versión. El programa imprime temperaturas, flujos y verificaciones, y genera la gráfica correspondiente.

## Estado de los requisitos
La adaptación, el informe completo firmado y el video aún no están terminados. Falta incorporar la plantilla de prompts del GitHub de la clase. Las auditorías aquí organizadas registran la revisión asistida por AI; la evidencia de cálculo manual y su certificación corresponden a las estudiantes.

